# OXXO Pay Payment Stub

This is an example of this OXXO Pay payment stub:

![OPPS](https://github.com/conekta-examples/oxxopay-payment-stub/blob/master/readme-files/opps_demo.png)
