# SPEI Payment Stub

This is an example of a SPEI payment stub:

![SPS](https://github.com/conekta-examples/spei-payment-stub/blob/master/readme-files/sps_demo.png)
